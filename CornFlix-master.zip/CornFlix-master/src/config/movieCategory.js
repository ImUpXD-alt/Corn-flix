const MOVIE_CATEGORIES = ["now_playing", "popular", "top_rated", "upcoming"];
export default MOVIE_CATEGORIES;
